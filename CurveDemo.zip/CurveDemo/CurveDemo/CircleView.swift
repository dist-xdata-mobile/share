//
//  CircleView.swift
//  CurveDemo
//
//  Created by wy on 2018/3/8.
//  Copyright © 2018年 wy. All rights reserved.
//

import UIKit

class CircleView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    convenience init(r: CGFloat,point: CGPoint) {
        self.init(frame: CGRect(x: 0, y: 0, width: 2*r, height: 2*r))
        self.layer.cornerRadius = r
        self.center = point
        
    }
    
    func animate() {
        let animation = CAKeyframeAnimation(keyPath: "transform")
        animation.duration = 2
        let trans = CATransform3DMakeScale(0.1, 0.1, 1.0)
        animation.values = [trans]
        self.layer.add(animation, forKey: nil)
        
    }
    
    
}
