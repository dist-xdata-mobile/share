//
//  ViewController.swift
//  CurveDemo
//
//  Created by wy on 2018/3/8.
//  Copyright © 2018年 wy. All rights reserved.
//

import UIKit
import Spring

class ViewController: UIViewController {

    var isShowOut = false
    var circle: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        circle = CircleView(r: 200, point: self.view.center)
        circle.backgroundColor = .lightGray
        self.view.addSubview(circle)
        for i in 0 ..< 7 {
            let item = SpringView(frame: CGRect(x: 0, y: 0, width: 44, height: 44))
            let w = 200 - 8 - Double(22)
            let si = w*sin(Double.pi/8*Double(i))
            let co = w*cos(Double.pi/8*Double(i))
            item.tag = i
            item.center = CGPoint(x: 200 - si, y: 200 + co)
            item.backgroundColor = .orange
            circle.addSubview(item)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        isShowOut = !isShowOut
        for view in circle.subviews {
            if let spring = view as? SpringView {
                if isShowOut {
                    spring.animation = "fadeIn"
                } else {
                    spring.animation = "fadeOut"
                }
                spring.duration = 1
                spring.scaleX = 
                let w = 200 - 8 - Double(22)
                let si = w*sin(Double.pi/8*Double(spring.tag))
                let co = w*cos(Double.pi/8*Double(spring.tag))
                spring.x = CGFloat(si)
                spring.y = -CGFloat(co)
                spring.animate()
            }
        }
    }


}

